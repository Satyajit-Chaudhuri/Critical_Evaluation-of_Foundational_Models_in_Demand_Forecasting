This is the monthly forecasting notebook
