This is monthly forecasting done with the TimeGPT finetuned models
